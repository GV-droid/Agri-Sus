# Agri Sus: demo video script (3 min 43 s)

> **Rule from the official Terms & Conditions:** the video must be **strictly three to four minutes long**.
> A video under 3:00 or over 4:00 breaks the rule. This script runs about **3:43**, leaving about 15 seconds of
> margin before the 4:00 limit. Check the length of the final export before you upload it.

How the video earns points (official weights):

| Criterion | Weight | Where the video shows it |
|---|---|---|
| Technical merit & Gen AI | 40% | Scenes 7–9: a Gemini agent with 15 tools, Google Search grounding with citations, BigQuery from plain English, voice in Hindi. Scene 3: an optimiser with about 129,000 variables. Scene 9: the Google Cloud architecture |
| Problem alignment & impact | 25% | Scenes 1, 3 and 4: imports, groundwater and farmer income in measurable numbers, plus the return on every rupee |
| Innovation & creativity | 25% | Scenes 4–7: least-cost mode, trade shocks, the next-crop decision, explanations of every choice |
| User experience & design | 10% | The whole video: map, ▶ animation, one-click brief, voice |

---

## Before you record (about 25 minutes, once)

1. **Redeploy with the latest files** (see [DEPLOY.md → Updating the site](DEPLOY.md#updating-the-site-after-a-code-change)).
   Then open `https://YOUR-URL/api/meta` and check that:
   - `gemini.backend` says `Vertex AI`;
   - `data_backend` says `BigQuery`.
2. **Keep one server warm, and only one.** Use `MIN_INSTANCES=1`, the default. Open the site **10 minutes before
   recording**: the server pre-solves every preset scenario at start-up (about 7 minutes), so clicking a preset then
   takes about 2 seconds. Plans and briefs are cached in the memory of *one* server, so make sure every click reaches
   the same one: in Cloud Shell run
   `gcloud run services update agri-sus --region us-central1 --session-affinity` once. Don't run load tests just before
   recording; if you did, wait 15 minutes so the extra servers shut down.
3. **Pre-warm the slow features.** Each one is cached once it has run:
   - Click the **✦ Gemini live outlook** scenario once and wait for the map to update (up to about 1½ minutes the
     first time). The outlook is cached for 6 hours.
   - **Reload the page** so you are back on the default plan.
   - Pick **Punjab** in the *Zoom to state* box and click **✦ Policy brief**. Wait for the English brief.
   - Then choose **हिन्दी** and wait for the Hindi brief.
   - Close the brief and set the state box back to *All India*. Briefs are cached for that exact plan, state and
     language until the server restarts. That is why scene 8 starts with a reload.
   - Pre-solve scene 4: click **Least cost to hit target**, then **Run optimizer**, and wait for the new budget path
     (about 45 seconds). It is then cached, so in the take it returns in about a second. **Reload the page** after.
4. **Rehearse the four co-pilot questions in scene 7 once.** Gemini's wording changes from run to run, so make sure
   you like the answers. Co-pilot answers are *not* cached, but the rehearsal also pre-solves the plan behind
   question 7b, so in the take it is usually much faster than the first time (about 50 seconds).
5. **Set up the browser:**
   - Google Chrome in a **Guest window**, so no extensions and no bookmarks bar.
   - Window **1920 × 1080**, or 1440 × 900 on a laptop, with zoom at 100%.
   - Open `https://YOUR-URL/?notour`. The `?notour` part skips the welcome tour.
   - Allow the **microphone** when Chrome asks; the Hindi voice question in scene 7 needs it.
   - Mute notifications: on macOS, turn on Focus / Do Not Disturb.
6. **Reset between takes:** reload the page. That clears the chat and returns to the baseline plan.

### Numbers to check on screen before you record

The narration uses the values below, taken from the default settings. After your redeploy, `/api/meta` →
`yield_engine.active` may switch to the BigQuery ML boosted tree, which only happens if it wins the hold-out test.
In that case a few numbers can shift slightly: **read them off your screen and adjust the line**.

| Scene | Where to look | Reference value |
|---|---|---|
| 3 | Scorecard, year 2030 | Do nothing **69.7**, Agri Sus plan **76.0** |
| 3 | KPI ribbon, 2030 | Imports **$27.1 bn → $21.5 bn** (−$5.6 bn). Groundwater **8.7 BCM**/yr saved. Pulses self-sufficiency **78% → 92%**. Farmer income **100.1%** of today |
| 3 | 🌍 Sustainability forecast, stress tests | Worst year under an unplanned El Niño: **71.6**, still above doing nothing |
| 4 | 💰 Budget & returns | ₹6,000 cr split into **₹3,299 cr** transfers, **₹1,789 cr** seed & FPO kits and **₹911 cr** price support. Public return **8.2×** |
| 4 | Least cost to hit target | **₹10,727 cr**/yr by 2030 (₹2,537 → 5,131 → 7,851 → 10,727 cr) |
| 5 | 🚢 Trade shocks | Indonesia: **49%** of palm oil, **3,882 kt**. About **2.2 Mt** replaced at home by 2030. Malaysia supplies **31%** |
| 6 | Sangrur district card | Groundwater at **310%** of recharge. Paddy **−10,172 ha**, moong **+10,172 ha**. **50 MCM**/yr of water saved. Score **19.1 → 21.7**. Next crop for Kharif 2027: **moong**; closest rejected alternative: **sesame** |
| 7 | Co-pilot, question 2 | About **₹16,300 cr**/yr by 2030 (₹3,745 → 7,629 → 11,842 → 16,288 cr). The 25% target is missed by only about $0.07 bn, and no district loses income |
| 7 | Co-pilot, question 3 | On BigQuery: Jaisalmer (Rajasthan) 322%, Sangrur 310%, Malerkotla 302%, Jalandhar 281%… The order can differ if Gemini filters differently |

---

## The script

Each scene lists what to do on **🎬 screen**, what to say (**🎙 voice-over**), and an optional **🏷 caption** to add
while editing. The voice-over is about 460 words (numbers take longer to say), roughly 3½ minutes at a calm 140
words a minute; the rest is room for pauses and on-screen action.

### Scene 1 · The problem (0:00 – 0:20)

🎬 **Screen**
- The live site, full India map.
- Map layer **Groundwater use vs recharge**; map mode **Do nothing**.
- Pick **Punjab** in *Zoom to state*: the map flies to the red districts. Hold for 2 seconds, then go back to *All India*.

🎙 **Voice-over**
> "India spends about twenty-three billion dollars a year importing pulses and edible oils. Meanwhile, Punjab's paddy
> fields pump groundwater up to three times faster than rain refills it. Shifting crops could fix both, if farmers
> don't lose income and India still grows enough grain."

🏷 **Caption:** *$23 bn imports (FY 2024-25) · Punjab pumps up to 310% of recharge*

### Scene 2 · Meet Agri Sus (0:20 – 0:36)

🎬 **Screen**
- Switch the layer to **District sustainability score** and the mode to **Agri Sus plan**.
- Slowly move the mouse over the left panel (scenarios and levers), then over the **Co-pilot** on the right.

🎙 **Voice-over**
> "Agri Sus is an AI co-pilot for agriculture planners. It plans crop shifts in every district of India, from 2027 to
> 2030, with a Google OR-Tools optimiser and a live Gemini agent."

🏷 **Caption:** *752 districts · 2027–2030 · built on Google Cloud*

### Scene 3 · The plan and the forecast (0:36 – 1:07)

🎬 **Screen**
- Press **▶** on the year bar: the map animates 2027 → 2030.
- Click **Do nothing**, then **Agri Sus plan**, then **Difference**: the green shows where the plan helps.
- Point at the scorecard (**69.7 → 76.0**) and the KPI ribbon.
- Open the **🌍 Sustainability forecast** tab and point at the stress-test band.

🎙 **Voice-over**
> "Press play and the plan unfolds. By 2030, our sustainability index reaches 76, against 70 if we do nothing.
> Imports fall by five-point-six billion dollars a year, groundwater pumping by 8.7 billion cubic metres, and pulse
> self-sufficiency rises from 78 to 92 percent. No district's farmers earn less than today. And under a surprise
> El Niño, the plan still beats doing nothing."

🏷 **Caption:** *Google OR-Tools · 129,000-variable linear program · optimal plan for 752 districts*

### Scene 4 · What it costs, what it returns (1:07 – 1:32)

🎬 **Screen**
- Open **💰 Budget & returns**: the policy mix, the fiscal ledger and the MROPI tiers.
- Click **show on map**: the map switches to *Public return per rupee*.
- In the left panel click **Least cost to hit target**, then **Run optimizer**. Show the new budget path. If you
  pre-solved it (*Before you record*, step 3) it returns in about a second; otherwise the solve takes about 45
  seconds, so cut the wait in editing.

🎙 **Voice-over**
> "The optimiser splits a six-thousand-crore budget between cash transfers, seed kits and price support. Savings in
> forex, power and fertiliser subsidies return eight times the outlay, and the map shows where each rupee works
> hardest. The cheapest way to cut imports by a quarter? About ten thousand seven hundred crore a year by 2030."

🏷 **Caption:** *Fiscal ledger · MROPI = public return per rupee · least-cost mode*

### Scene 5 · A trade shock (1:32 – 1:50)

🎬 **Screen**
- Click **Reset**. Then click the scenario **Indonesia halts palm-oil exports**; it is pre-solved, so the update is instant.
- Open **🚢 Trade shocks**: volume to replace, substitute crops, other suppliers and supplier concentration.

🎙 **Voice-over**
> "What if Indonesia, half our palm-oil supply, stops selling? Using India Data Portal trade data, Agri Sus
> re-plans: groundnut, mustard and soybean replace 2.2 million tonnes by 2030, and it lists who can supply the rest."

🏷 **Caption:** *India Data Portal · DGCI&S country-wise imports*

### Scene 6 · Every decision explained (1:50 – 2:12)

🎬 **Screen**
- Click **Baseline (CMIP6 SSP2-4.5)**.
- Pick **Punjab** in *Zoom to state* and click **Sangrur**: the district card opens on **Plan & why**. Sangrur is in
  south-central Punjab, south of Ludhiana; hover over districts to see their names. Point at the moves, the reasons
  and the rejected alternatives.
- Click **🌱 Next crop**.

🎙 **Voice-over**
> "Every decision is explained. Sangrur pumps three times its recharge. The plan swaps ten thousand hectares of paddy
> for moong, saving fifty million cubic metres of water a year, and shows why, what it rejected and the cost. Next
> Kharif, it recommends moong over sesame, and says why."

🏷 **Caption:** *Decision trace · shadow prices & reduced costs from the optimiser*

### Scene 7 · The live Gemini agent (2:12 – 3:03)

This is the most important scene (40% of the score). Record each question as its own clip. Keep 1–2 seconds of
the streamed tool steps on screen, then cut the waiting time. If you speed a wait up instead, show a small
**⏩ sped up** badge. Judges value honesty.

**7a · Grounded outlook (chat must be empty, so reload first)**

🎬 **Screen**
- Click the suggestion chip **"What is the latest IMD / ENSO outlook and edible-oil import duty? Re-run the plan with it."**
- Show the steps streaming (`web_grounded_search`, `gemini_outlook_forecast`), then the answer.
- Scroll to the **citation links** under the answer.

🎙 **Voice-over**
> "Now the live agent: Gemini on Vertex AI, with fifteen tools. I ask about today's monsoon outlook and import duty.
> Gemini searches Google, cites its sources, turns the outlook into climate and price shocks, and re-runs the
> optimiser with them."

🏷 **Caption:** *Gemini on Vertex AI · function calling · Grounding with Google Search*

**7b · A hard what-if**

🎬 **Screen**
- Type: **"If Indonesia halts palm-oil exports and El Niño hits in 2028, what is the least annual budget that still
  cuts imports 25%, with no farmer losing income?"**
- Show the `run_simulation` step with its arguments (`min_budget`, the trade cut, the El Niño scenario).
- Show the answer, then the map and sliders updating.

🎙 **Voice-over**
> "Something harder: a palm-oil embargo plus an El Niño, at least cost. Gemini picks the tool, sets the levers, and
> the answer, about sixteen thousand crore a year, moves the dashboard with it."

**7c · BigQuery in plain English**

🎬 **Screen**
- Type: **"Which 10 districts have the worst groundwater stage and how much paddy do they grow? Use BigQuery."**
- Show the `get_schema` and `query_bigquery` steps, then the table.

🎙 **Voice-over**
> "It also writes read-only SQL on BigQuery to answer ad-hoc questions straight from the data."

🏷 **Caption:** *Natural language → BigQuery SQL (read-only, sandboxed)*

**7d · Hindi, by voice**

🎬 **Screen**
- Set the co-pilot language box to **हिन्दी**, press **🎤** and say:
  **"पंजाब में धान की जगह कौन सी फसल उगाएँ?"**
  - Read aloud as: *"Punjab mein dhaan ki jagah kaun si fasal ugaayein?"*
  - Meaning: *Which crop should Punjab grow instead of paddy?*
  - If speech recognition struggles, paste the Hindi text instead.
- When the Hindi answer appears, click **🔊 Listen** and let 3 seconds play.

🎙 **Voice-over**
> "And it speaks the farmer's language: eleven Indian languages, by voice."

🏷 **Caption:** *11 Indian languages · voice in and out*

### Scene 8 · One-click policy brief (3:03 – 3:13)

🎬 **Screen**
- *Before this clip:* reload the page. Scene 7 changed the plan, and the pre-warmed brief belongs to the default plan.
- Pick **Punjab** in *Zoom to state* and click **✦ Policy brief**.
- Choose **हिन्दी**; it is pre-warmed, so it appears at once. Scroll it slowly.
- Point at **Print / PDF**.

🎙 **Voice-over**
> "One click turns any plan into a ministerial brief, for India or any state, in any of those languages."

🏷 **Caption:** *Gemini-written brief from the run's own numbers*

### Scene 9 · Built on Google Cloud (3:13 – 3:31)

🎬 **Screen**
- Show the architecture diagram, from your deck or from [HOW_IT_WORKS.md](HOW_IT_WORKS.md#4-architecture-on-google-cloud).
- Cut for 3 seconds to `https://YOUR-URL/api/meta` with `Vertex AI`, `BigQuery` and `yield_engine` highlighted.
- Earth Engine is optional. Unless you ran the Earth Engine step ([DEPLOY.md](DEPLOY.md#optional-google-earth-engine-climate-pipeline))
  and `/api/meta` → `climate_source` starts with *Google Earth Engine*, keep the word **can** in the last sentence.

🎙 **Voice-over**
> "Under the hood, it's all Google Cloud: Cloud Run serves the app, Gemini on Vertex AI with Search grounding runs
> the agent, BigQuery stores the data and every run, BigQuery ML trains a yield model, and Earth Engine can
> recompute district climate."

🏷 **Caption:** *Cloud Run · Vertex AI Gemini · Google Search grounding · BigQuery · BigQuery ML · Vertex AI Model Registry · Earth Engine · Cloud Build · Artifact Registry · one-command deploy*

### Scene 10 · Close (3:31 – 3:43)

🎬 **Screen**
- Back on the India map in **Difference** mode.
- Fade to an end card:
  - **Agri Sus: climate-resilient crop policy for India**
  - your live URL
  - your GitHub URL
  - team name

🎙 **Voice-over**
> "Agri Sus turns public data into plans a ministry can fund, explain and defend: less import dependence, healthier
> aquifers, and no farmer left worse off."

---

## Timing summary

| # | Scene | Starts | Length |
|---|---|---|---|
| 1 | The problem | 0:00 | 20 s |
| 2 | Meet Agri Sus | 0:20 | 16 s |
| 3 | The plan and the forecast | 0:36 | 31 s |
| 4 | What it costs, what it returns | 1:07 | 25 s |
| 5 | A trade shock | 1:32 | 18 s |
| 6 | Every decision explained | 1:50 | 22 s |
| 7 | The live Gemini agent (4 questions) | 2:12 | 51 s |
| 8 | One-click policy brief | 3:03 | 10 s |
| 9 | Built on Google Cloud | 3:13 | 18 s |
| 10 | Close | 3:31 | 12 s |
| | **Total** | | **3:43** |

- **If you run long,** shorten scene 2 to *"Agri Sus is an AI co-pilot for agriculture planners, built on Google
  Cloud."* and drop question 7c.
- **If you run short,** let the ▶ animation in scene 3 and the Hindi audio in 7d play longer.
- **Never go below 3:00 or above 4:00.**

## Recording and editing, step by step

1. **Record the screen, one clip per scene.** That makes retakes easy.
   - **Mac:** press **⌘ Shift 5**, choose *Record Selected Portion*, drag over the browser window, then click *Record*.
     Stop with the ⏹ button in the menu bar.
   - **Windows:** use the screen recorder in **Clipchamp**, or press **Win + G** (Xbox Game Bar).
2. **Record the voice-over separately** in a quiet room, using a headset microphone if you have one. Read each scene's
   lines as their own audio clip. *(Or narrate live while recording if you prefer.)*
3. **Edit** in iMovie (Mac), Clipchamp (Windows), CapCut or Google Vids:
   - put the clips in order and lay each voice-over clip under its scene;
   - trim the waits;
   - add the 🏷 captions as lower-third titles;
   - optionally add quiet background music from the YouTube Audio Library (copyright-free).
4. **Check the length** in the editor's timeline: it must be between **3:00 and 4:00**.
5. **Export** as MP4, 1080p.
6. **Upload** the way the submission form asks, for example YouTube as *Unlisted*. Open the link in a private window
   to make sure it plays for others.

### If something goes wrong while recording

| Problem | What to do |
|---|---|
| A co-pilot answer takes long | Normal for multi-step questions: cut the wait in editing. If it says *"Gemini did not answer in time"*, reload and ask again |
| The model tag under an answer says `offline-rule-router` or `local fallback` | Gemini was not reached. Check `/api/meta` and see [DEPLOY.md → Troubleshooting](DEPLOY.md#troubleshooting), then re-take |
| The 🎤 button is missing or hears nothing | Use Chrome and allow the microphone (🔒 in the address bar → Microphone → Allow). Or paste the Hindi question |
| A number on screen differs from the script | Say the number you see. See *Numbers to check* above |
| The first click after a pause is slow | Keep the site open while recording. With `MIN_INSTANCES=1` the server stays warm |

## YouTube description template

```
Agri Sus — an AI co-pilot for climate-resilient crop policy in India (Google Cloud AI Builder Cup 2026,
Sustainability & Social Impact).

Live app: https://YOUR-URL/
Code: https://github.com/YOUR_GITHUB_USER/agrisus

0:00 The problem: $23 bn imports, aquifers at 300% of recharge
0:20 Agri Sus: every district of India, 2027–2030
0:36 The plan vs doing nothing, stress-tested
1:07 Budget, fiscal return and least-cost mode
1:32 Trade shock: Indonesia halts palm-oil exports
1:50 Every decision explained (Sangrur)
2:12 Live Gemini agent: grounding, what-ifs, BigQuery, Hindi voice
3:03 One-click policy brief
3:13 Built on Google Cloud
3:31 Close

Built with Cloud Run, Vertex AI Gemini, Grounding with Google Search, BigQuery, BigQuery ML,
Vertex AI Model Registry, Google Earth Engine, Cloud Build, Artifact Registry and Google OR-Tools.
```
